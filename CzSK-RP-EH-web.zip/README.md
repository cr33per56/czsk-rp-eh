# Cz/Sk RP [EH] – web

Hotový statický web pro Roblox Emergency Hamburg.

## Zdarma zveřejnění
Nejjednodušší je GitHub Pages:
1. Vytvoř veřejný GitHub repository.
2. Nahraj `index.html`, `style.css` a `logo.jpeg`.
3. V repository otevři Settings → Pages.
4. Jako zdroj vyber deploy z větve `main` a složku `/ (root)`.
5. GitHub ti vytvoří adresu ve tvaru `https://TVUJ-UCET.github.io/NAZEV-REPO/`.

Discord: https://discord.gg/EHJggmQst
